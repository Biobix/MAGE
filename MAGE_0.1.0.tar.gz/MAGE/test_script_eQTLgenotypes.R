#EMASE = Expectation Maximization for Allele Specific Expression
library(MAGE)

########
#PARAMS#
########
wdirect <- "/data/jeroeng/TCGAkidney/GTEX/Counts/"
wd_samples <- "/data/jeroeng/TCGAkidney/GTEX/"
wd_res <- "/data/jeroeng/TCGAkidney/GTEX/cis-eQTL_new/"
wd_seqem <- "/data/jeroeng/TCGAkidney/GTEX/seqem_ase/"

norms <- read.table("/data/MAGE_nogit/flagstat_kidney_control.txt", header = T, sep = "\t")
norms$file <- gsub("/data/jeroeng/TCGAkidney/bamfiles/", "", norms$file)
norms$file <- gsub(".bam", "", norms$file)
#row.names(norms) <- norms$file
norms <- data.frame("counts" = norms$mapped, "sample" = norms$file)
norms$counts <- norms$counts / mean(norms$counts)

file_samples <- paste(wd_samples, "kidney_samples.txt", sep = "")
sample_info <- read.table(file_samples, header = FALSE, stringsAsFactors = FALSE, sep = "\t")
names(sample_info) <- c("sample_nr", "sample")
samples_all <- sample_info$sample
nr_samples_all <- length(samples_all)

chromosomes <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22)
dltaco <- 0.001
pA_estimate_filt <- 0.1
pA_filt <- 0.15
cov_filt <- 4
nr_samples_filt <- 40
SE_filt <- 0.035
GOF_filt <- 1
FDR_filt <- 0.05
SHIFT_filt <- 0.2
MED_SHIFT_filt <- 0.2
plot_coverage <- 40
plot_h0 <- FALSE

###########
#FUNCTIONS#
###########
lrt_etl_geno <- function (data_counts, norm_counts, allelefreq, SE, inbr = 0, dltaco = 0.001, HWE = TRUE) {
  mean_norms <- mean(norm_counts[, "counts"])
  norm_counts <- norm_counts[match(data_counts$sample, norm_counts$sample), ]
  norm_counts$norms <- norm_counts[, "counts"]/mean_norms
  data_counts[, c("ref_norm", "var_norm")] <- data_counts[, c("ref_count", "var_count")]/norm_counts$norms
  rawcor <- cor.test(data_counts$ref_norm + data_counts$var_norm, data_counts$ref_count/(data_counts$ref_count + data_counts$var_count))

  probshift <- 0.5
  dlta <- 1
  nrep <- 0
  prv <- 2 * allelefreq * (1 - allelefreq) * (1 - inbr)
  pr <- allelefreq^2 + inbr * allelefreq * (1 - allelefreq)
  pv <- (1 - allelefreq)^2 + inbr * allelefreq * (1 - allelefreq)

  while (dlta > dltaco & nrep < 100) {
    nrep <- nrep + 1
    probshiftold <- probshift
    spv <- pv * dbinom(data_counts$var_count, data_counts$ref_count + data_counts$var_count, prob = 1 - SE)
    sprv <- prv * dbinom(data_counts$ref_count, data_counts$ref_count + data_counts$var_count, prob = probshift)
    spr <- pr * dbinom(data_counts$ref_count, data_counts$ref_count + data_counts$var_count, prob = 1 - SE)
    pdata <- rowSums(cbind(spv, sprv, spr))

    if (any(pdata == 0) | identical(sprv, pdata) | all(round(sprv/pdata) == 1)) {
      data_counts$pvv <- spv; data_counts$prr <- spr; data_counts$prv <- sprv

      dmixase <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr)
      dmixh0 <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, 0.5, allelefreq, SE, inbr)
      lrtstat <- -2 * (sum(log(dmixh0)) - sum(log(dmixase)))
      pval <- pchisq(lrtstat, df = 1, lower.tail = F)
      dmixase_corrected <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr) * (data_counts$ref_count + data_counts$var_count + 1)
      logLikelihood <- mean(log(dmixase_corrected))
      probshift_adj <- -(as.numeric(probshift) - 0.5)/0.5

      results <- list(AE = probshift_adj, AE_lrt = lrtstat, AE_p = pval, GOF = logLikelihood, nrep = nrep - 1, rawcor_p = rawcor$p.value, rawcor_R = rawcor$estimate, quality = "!", pvv = pv ,prr = pr, prv = prv, data_hash = data_counts)
      return(results)
    }

    spv <- spv/pdata
    sprv <- sprv/pdata
    spr <- spr/pdata
    if (HWE) {
      allelefreq <- mean(spr) + mean(sprv)/2
      prv <- 2 * allelefreq * (allelefreq) * (1 - inbr)
      pr <- allelefreq^2 + inbr * allelefreq * (1 - allelefreq)
      pv <- (1 - allelefreq)^2 + inbr * allelefreq * (allelefreq)
    }
    else {
      pv <- sum(spv)
      prv <- sum(sprv)
      pr <- sum(spr)
    }
    aaf <- (spv * 2 + sprv)/2
    probshiftlm <- coef(MASS::rlm(data_counts$ref_norm + data_counts$var_norm ~ aaf))
    probshift <- probshiftlm[1]/(2 * probshiftlm[1] + probshiftlm[2])
    probshift[probshift > 1] <- 1
    probshift[probshift < 0] <- 0
    dlta <- abs(probshiftold - probshift)
  }
  data_counts$pvv <- spv; data_counts$prr <- spr; data_counts$prv <- sprv

  dmixase <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr)
  dmixh0 <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, 0.5, allelefreq, SE, inbr)
  lrtstat <- -2 * (sum(log(dmixh0)) - sum(log(dmixase)))
  pval <- pchisq(lrtstat, df = 1, lower.tail = F)
  dmixase_corrected <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr) * (data_counts$ref_count + data_counts$var_count + 1)
  logLikelihood <- mean(log(dmixase_corrected))
  probshift_adj <- -(as.numeric(probshift) - 0.5)/0.5

  results <- list(AE = probshift_adj, AE_lrt = lrtstat, AE_p = pval, GOF = logLikelihood, nrep = nrep, rawcor_p = rawcor$p.value, rawcor_R = rawcor$estimate, quality = "", pvv = pv ,prr = pr, prv = prv, data_hash = data_counts)
  return(results)
}

#######
#START#
#######
for (chr in chromosomes) {
  print(chr)
  #READ COUNT FILES
  sample_data <- data.table::fread(paste(wdirect,"counts_SNP_chr", chr, ".txt", sep=""), header = FALSE, stringsAsFactors = F, sep = "\t", data.table = getOption("datatable.fread.datatable", FALSE))
  names(sample_data) <- c("chromosome", "position", "ref_alleles", "variationtype", "dbSNP_ref", "gene", "A", "T", "C", "G", "sample")
  sample_data$sample_nr <- unlist(lapply(sample_data$sample, function(x) sample_info[which(sample_info$sample == x), "sample_nr"]))
  sample_data$position <- as.character(sample_data$position)

  #DETERMINE AMOUNT OF LOCI
  positions <- unique(sample_data$position)
  loci <- length(positions)

  #CREATE HASH WITH DATA FRAME FOR EVERY POSITION
  data <- hash::hash()
  for (i in positions) {
    data[[ i ]] <- sample_data[which(sample_data$position==i), ]
  }

  #DELETE INDELS AND SUBSTITUTIONS
  for (z in positions) {
    if (data[[z]]$variationtype[1] != "SNV" || grepl('\\.', strsplit(data[[z]]$ref_alleles[1], "/"))) {
      data[[z]] <- NULL
    }
  }
  positions <- hash::keys(data); loci <- length(positions)

  #DETERMINE STANDARD ALLELES AND REFERENCE/VARIANT COUNTS
  for (z in positions) {
    data[[z]] <- MAGE::standard_alleles(data[[z]])
  }

  #PRIOR FILTER OF LOCI
  for (z in positions) {
    data[[z]] <- MAGE::prior_filter(data[[z]], prior_allelefreq = pA_estimate_filt, coverage_filter = cov_filt, samples_filter = nr_samples_filt)
  }
  positions <- hash::keys(data); loci <- length(positions)

  #ESIMATE PARAMETERS WITH SeqEM (SEQUENCING ERROR RATE, ALLELE FREQUENCY AND INBREEDING), CALCUTE SYMMETRY GOF PER SNP AND FILTER SNPS
  SE_all <- NULL; F_all <- NULL
  for (z in positions) {
    seqem_results <- MAGE::estimate_parameters(data[[z]]$ref_count, data[[z]]$var_count, wd_seqem, ref_allele = data[[z]][1, "ref"], var_allele = data[[z]][1, "var"], position = z, dbSNP = data[[z]][1, "dbSNP_ref"], chr = chr)
    data[[z]]$allelefreq <- seqem_results$allelefreq
    data[[z]]$est_SE <- seqem_results$SE
    data[[z]]$est_inbr <- seqem_results$inbr
    SE_all <- c(SE_all, seqem_results$SE)
    F_all <- c(F_all, seqem_results$inbr)

    if (seqem_results$allelefreq <= pA_filt || seqem_results$allelefreq >= (1 - pA_filt) || seqem_results$SE > SE_filt) {
      data[[z]] <- NULL
    }
  }
  f_inb_chr <- median(F_all)
  SE <- median(SE_all)
  positions <- hash::keys(data); loci <- length(positions)

  #PERFORM IMPRINTING ANALYSIS PER SNP AND CREATE RESULTS DATA FRAME
  f2 <- file(paste(wd_res, "chr", chr, "_eQTL_genotypes.txt", sep = ""), "w")
  writeLines(paste("position", "prr", "prv", "pvv", "sample_id", "sample_nr", sep = "\t"), f2)

  results <- data.frame()
  for (z in positions) {
    lrt_results <- lrt_eqtl_geno(data[[z]], norms, allelefreq = data[[z]]$allelefreq[1], SE = SE, inbr = f_inb_chr, dltaco = dltaco, HWE = TRUE)
    med_ase <- MAGE::median_eqtl(data[[z]]$ref_count, data[[z]]$var_count, data[[z]]$allelefreq[1], f_inb_chr)

    data_geno <- lrt_results$data_hash
    out <- writeLines(paste(z, data_geno$prr, data_geno$prv, data_geno$pvv, data_geno$sample, data_geno$sample_nr, sep = "\t"), f2)

    results_z <- data.frame("position" = z, "gene" = data[[z]]$gene[1], "probshift" = as.numeric(lrt_results$AE), "LRT" = as.numeric(lrt_results$AE_lrt), "p" = as.numeric(lrt_results$AE_p), "quality" = lrt_results$quality, "allele.frequency" = data[[z]]$allelefreq[1], "dbSNP" = data[[z]]$dbSNP_ref[1], "reference" = data[[z]]$ref[1], "variant" = data[[z]]$var[1], "est_SE" = data[[z]]$est_SE[1], "coverage" = data[[z]]$coverage[1], "nr_samples" = nrow(data[[z]]), "GOF" = lrt_results$GOF, "median_ASE" = med_ase, "est_inbreeding" = data[[z]]$est_inbr[1], "tot_inbreeding" = f_inb_chr, "nrep" = as.numeric(lrt_results$nrep), "rawcor_p" = as.numeric(lrt_results$rawcor_p), "rawcor_R" = as.numeric(lrt_results$rawcor_R), "homo_var" = lrt_eqtl$pvv, "homo_ref" = lrt_eqtl$prr, "hetero" = lrt_eqtl$prv, stringsAsFactors = FALSE)
    results <- rbind(results, results_z)
  }

  f3 <- file(paste(wd_res, "chr", chr, "_eQTL_results_all.txt", sep = ""), "w")
  out <- write.table(results, f3, row.names = FALSE, sep = "\t")
  close(f3)

  #ONLY RETAIN GOOD QUALITY DATA WITH MINIMAL GoF
  if (any(results$quality == "!")) results <- results[-which(results$quality == "!"), ]
  results_fit <- results[-which(results$GOF <= GOF_filt), ]
  positions <- results_fit$position; loci <- length(positions)

  #RECALCULATE INBREEDING AND SEQUENCING ERROR RATE WITH ONLY GOOD QUALITY DATA
  f_inb_chr_fit <- median(results_fit$est_inbreeding)
  SE_fit <- MAGE::error_nonstandard(data[positions])

  f2 <- file(paste(wd_res, "SE_inbr_chr", chr, ".txt", sep = ""), "w")
  out <- write.table(data.frame("parameter" = c("SE", "inbr", "SE_bad", "inbr_bad"), "value" = c(SE_fit, f_inb_chr_fit, SE, f_inb_chr)), f2, quote = F, sep = "\t")
  close(f2)

  results_new <- data.frame()
  for (z in positions) {
    lrt_results <- lrt_eqtl_geno(data[[z]], norms, allelefreq = data[[z]]$allelefreq[1], SE = SE_fit, inbr = f_inb_chr_fit, dltaco = dltaco, HWE = TRUE)
    med_ase <- MAGE::median_eqtl(data[[z]]$ref_count, data[[z]]$var_count, data[[z]]$allelefreq[1], f_inb_chr_fit)
    results_z <- data.frame("position" = z, "gene" = data[[z]]$gene[1], "probshift" = as.numeric(lrt_results$AE), "LRT" = as.numeric(lrt_results$AE_lrt), "p" = as.numeric(lrt_results$AE_p), "quality" = lrt_results$quality, "allele.frequency" = data[[z]]$allelefreq[1], "dbSNP" = data[[z]]$dbSNP_ref[1], "reference" = data[[z]]$ref[1], "variant" = data[[z]]$var[1], "est_SE" = data[[z]]$est_SE[1], "coverage" = data[[z]]$coverage[1], "nr_samples" = nrow(data[[z]]), "GOF" = lrt_results$GOF, "median_ASE" = med_ase, "est_inbreeding" = data[[z]]$est_inbr[1], "tot_inbreeding" = f_inb_chr_fit, "nrep" = as.numeric(lrt_results$nrep), "rawcor_p" = as.numeric(lrt_results$rawcor_p), "rawcor_R" = as.numeric(lrt_results$rawcor_R), "homo_var" = lrt_eqtl$pvv, "homo_ref" = lrt_eqtl$prr, "hetero" = lrt_eqtl$prv, stringsAsFactors = FALSE)
    results_new <- rbind(results_new, results_z)
  }

  #REMOVE BAD QUALITY LOCI & FINAL FILTER ON ADJUSTED P AND (MEDIAN) ASE & WRITE RESULTS FILES
  if (any(results_new$quality == "!")) results_new <- results_new[-which(results_new$quality == "!"), ]
  results <- MAGE::final_filter_eqtl(chr, data, results_new, wd_res, gof_filt = GOF_filt, adj_p_filt = FDR_filt, shift_filt = SHIFT_filt, med_ase_filt = MED_SHIFT_filt, file_all = FALSE, file_eqtl = TRUE, file_all_counts = FALSE, file_eqtl_counts = FALSE)
  #
  #   positions_res <- as.character(results$position)
  #
  #   #PLOT SIGNIFICANTLY IMPRINTED GENES#
  #   if (length(positions_res) > 0) {
  #     for (z in positions_res) {
  #       MAGE::plot_eqtl(data[[z]]$ref_count, data[[z]]$var_count, probshift = results[which(results$position==z), "probshift"], allelefreq = results[which(results$position==z), "allele.frequency"], SE = SE_fit, wd_res = wd_res, chr = chr, position = z, gene  = results[which(results$position==z), "gene"], inbr = f_inb_chr_fit, coverage = plot_coverage, plot_H0 = plot_h0)
  #     }
  #   }
}
