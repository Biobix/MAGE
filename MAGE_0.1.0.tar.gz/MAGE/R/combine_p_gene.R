#' Combine p-values of SNPs per gene.
#'
#' \code{combine_p_gene} uses the harmonic mean of p-values to combine p-value of different SNPs
#'     per gene.
#'
#' @param p_values Numeric list. P-values to combine.
#' @export
#' @examples
#' combine_p_gene(c(0.015, 0.414, 8.47E-03, 7.43E-03, 0.574, 0.837))
#' combine_p_gene(c(0.063, 0.725, 0.657, 0.378, 0.291))

combine_p_gene <- function (p_values) {
  combined_p <- 1 / mean(1 / p_values)
  return(combined_p)
}
