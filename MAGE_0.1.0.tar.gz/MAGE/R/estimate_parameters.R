#' Estimate allele frequency, sequencing error rate and inbreeding using an Expectation-Maximisation algorithm.
#'
#' \code{estimate_parameters} calculates allele frequencies, sequencing error rates, inbreeding
#'     coefficients, genotypes and genotype probabilities from \code{ref_counts} and \code{var_counts}
#'     for a specific SNP.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param deltaF String. Expectation-Maximisation threshold, minimal difference between
#'     two consecutive iterations (default is 10^-8).
#' @param maxIT Number. Maximum number of iterations of the Expectation-Maximisation algorithm (default is 1000).
#' @param SE_prior Number. Initial estimate of the sequencing error rate (default is 0.002).
#' @param F_inbr_prior Number. Initial estimate of the inbreeding coefficient (default is NULL).
#' @param HetProb Number. Initial allelic fraction of the reference allele (default is 0.5).
#' @export
#' @return A list containing the following components:
#' \item{allelefreq}{The estimated allele frequency.}
#' \item{SE}{The estimated sequencing error rate.}
#' \item{F_inbr}{The estimated inbreeding coefficient.}
#' \item{genotypes}{The genotypes (rr, rv, vv) for each sample.}
#' \item{genoprobs}{The genotype probabilties (p(rr), p(rv), p(vv)) for each sample.}
#' \item{nrep}{The number of iterations}

estimate_parameters <- function(ref_counts, var_counts, deltaF = 10^-8, maxIT = 100, SE_prior = 0.002, F_inbr_prior = NULL, HetProb = 0.5) {

  delta <- 1
  nrep <- 0

  SE <- SE_prior
  if(is.null(F_inbr_prior)) {
    pr <- 1/3
    pv <- 1/3
    prv <- 1/3
  } else {
    tots <- ref_counts + var_counts
    rf <- mean(ref_counts/tots)
    vf <- 1-rf
    rf <- (rf - SE) / (1 - 2 * SE)
    vf <- (vf - SE) / (1 - 2 * SE)
    pr <- rf^2 + F_inbr_prior * rf * vf
    pv <- vf^2 + F_inbr_prior * rf * vf
    prv <- 1 - pr - pv
  }

  while(delta > deltaF & nrep < maxIT) {

    SEold <- SE
    prold <- pr
    pvold <- pv
    prvold <- prv

    nrep <- nrep + 1
    spr <- pr * dbinom(ref_counts, ref_counts + var_counts, prob = 1 - SE)
    spv <- pv * dbinom(var_counts,ref_counts + var_counts, prob = 1 - SE)
    sprv <- prv * dbinom(ref_counts, ref_counts + var_counts, prob = HetProb)

    pdata <- rowSums(cbind(spv, sprv, spr))

    if (any(pdata == 0)) {
      ProblemCases <- which(pdata == 0)
      for(case in ProblemCases){
        var_part <- var_counts[case]
        ref_part <- ref_counts[case]
        spv_part <- dbinom(var_part, ref_part + var_part, 1 - SE, log = TRUE)
        sprv_part <- dbinom(ref_part, ref_part + var_part, HetProb, log = TRUE)
        spr_part <- dbinom(ref_part, ref_part + var_part, 1 - SE, log = TRUE)
        spvec <- c(spr_part, sprv_part, spv_part)
        if(spr_part == max(spvec)) {
          spr[case] <- 1
          pdata[case] <- 1
        } else if(sprv_part == max(spvec)) {
          sprv[case] <- 1
          pdata[case] <- 1
        } else {
          spv[case] <- 1
          pdata[case] <- 1
        }
      }
    }

    if(sum(spr + spv) == 0) {
      allelefreq <- 1
      SE <- 1
      F_inbr <- 1
      genoprobs <- data.frame("p(rr)" = spr, "p(rv)" = sprv, "p(vv)" = spv)
      genotypes <- rep("NR", length(ref_counts))
      returnOBJ <- list(allelefreq, SE, F_inbr, genotypes, genoprobs)
      names(returnOBJ) <- c("allelefreq", "SE", "F_inbr", "genotypes", "genoprobs")
      return(returnOBJ)
    }

    # pdata toepassen;
    spr <- spr / pdata
    spv <- spv / pdata
    sprv <- sprv / pdata

    pv <- mean(spv)
    prv <- mean(sprv)
    pr <- mean(spr)

    tot_counts <- ref_counts + var_counts
    Nrr <- sum(tot_counts * spr)
    Nvv <- sum(tot_counts * spv)
    Xrr <- sum(var_counts * spr)
    Xvv <- sum(ref_counts*spv)
    SE <- (Xrr + Xvv) / (Nrr + Nvv)

    SEdif <- abs(SEold - SE)
    prdif <- abs(prold - pr)
    pvdif <- abs(pvold - pv)
    prvdif <- abs(prvold - prv)
    delta <- max(c(SEdif, prdif, pvdif, prvdif))

  }

  # allelefreq = frectie r-allelen
  allelefreq <- mean(spr) + mean(sprv)/2
  genoprobs <- data.frame("p(rr)" = spr, "p(rv)" = sprv, "p(vv)" = spv)
  genotypes <- c("rr", "rv", "vv")[apply(genoprobs, 1, function(x) which(x == max(x))[1])]

  F_inbr <- 1 - (sum(sprv) / (2 * allelefreq * (1 - allelefreq) * length(ref_counts)))
  # F_inbr <- 1 - (length(which(genotypes == "rv")) / (2*allelefreq*(1-allelefreq) * length(ref_counts)))

  returnOBJ <- list(allelefreq, SE, F_inbr, genotypes, genoprobs, nrep)
  names(returnOBJ) <- c("allelefreq", "SE", "F_inbr", "genotypes", "genoprobs", "nrep")
  return(returnOBJ)
}
