#' Probability Mass Function for cis-eQTLs.
#'
#' \code{pmf_eqtl} calculates the binomial probability of observing specific coverages for a putative cis-eQTL.
#'     It takes into account allele frequencies, sequencing error rates and inbreeding.
#'
#' @param ref_counts Number or Numeric list. Reference count(s).
#' @param var_counts Number or Numeric list. Variant count(s).
#' @param probshift Number. The binomial probability of success indicating the shift of the heterozygous fraction.
#' @param allelefreq Number. Allele frequency.
#' @param SE Number. Sequencing error rate.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @return Probability of observing coverages for \code{ref_counts} and \code{var_counts} with
#'     \code{probshift} as the probability of success.
#' @export
#' @examples
#' pmf_eqtl(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.5, 0.002, 0.12)
#' pmf_eqtl(c(5, 8, 10, 3, 5, 6, 23), c(5, 8, 10, 3, 5, 6, 23), 0.15, 0.5, 0.002, 0.12)
#' pmf_eqtl(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.15, 0.5, 0.002, 0.12)
#' pmf_eqtl(5, 8, 0.15, 0.5, 0.002, 0.12)

pmf_eqtl <- function(ref_counts, var_counts, probshift, allelefreq, SE, inbr = 0) {
  prv <- 2 * allelefreq * (1 - allelefreq) * (1 - inbr)
  pr <- allelefreq ^ 2 + inbr * allelefreq * (1 - allelefreq)
  pv <- (1 - allelefreq) ^ 2 + inbr * allelefreq * (1 - allelefreq)

  dmix <- pr * dbinom(ref_counts, ref_counts + var_counts, prob = 1 - SE) + pv * dbinom(var_counts, ref_counts + var_counts, prob = 1 - SE) + prv * dbinom(ref_counts, ref_counts + var_counts, prob = probshift)
  return(dmix)
}
