#' Estimate allele frequency, sequencing error rate and inbreeding with SeqEM.
#'
#' \code{estimate_parameters_seqem} calculates allele frequencies, sequencing error rates and inbreeding coefficients using SeqEM.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param wd_seqem String. Directory where SeqEM files are written to and/or where seqem.exe is located.
#' @param ref_allele Character. Reference allele used in the SeqEM files (default is A).
#' @param var_allele Character. Variant allele used in the SeqEM files (default is T).
#' @param position Number. Position of the analysed SNP used in the SeqEM files (default is 100).
#' @param dbSNP String. dbSNP id of the analysed SNP used in the SeqEM files (default is rs100).
#' @param chr Number. Chromosome used in the SeqEM files (default is 1).
#' @param HWE 0 or 1. Should Hardy-Weinberg be used for SeqEM yes (1) or no (0) (default is 0).
#' @param remove Logical. Should SeqEM files be removed (default is TRUE).
#' @param Debug Number. Debug option for SeqEM (default is 0).
#' @param MAX_iterations Number. Maximum number of iterations in SeqEM (default is 1000).
#' @param EM_threshold Number. EM_threshold option for SeqEM (default is 0.00000001).
#' @param Initial_error Number. Initial_error option for SeqEM (default is 0.01).
#' @param Fix_error Number. Fix_error option for SeqEM (default is 0).
#' @param Min_read_depth Number. Min_read_depth option for SeqEM (default is 1).
#' @export
#' @return A list containing the following components:
#' \item{allelefreq}{The estimated allele frequency.}
#' \item{SE}{The estimated sequencing error rate.}
#' \item{inbr}{The estimated inbreeding coefficient.}

estimate_parameters_seqem <- function(ref_counts, var_counts, wd_seqem, ref_allele = "A", var_allele = "T", position = 100, dbSNP = "rs100", chr = 1 , HWE = 0, remove = TRUE, Debug = 0, MAX_iterations = 100, EM_threshold = 0.00000001, Initial_error = 0.01, Fix_error = 0, Min_read_depth = 1) {
  old <- setwd(tempdir())

  nr_samples <- length(ref_counts)

  #INPUT FILE
  text <- paste(paste(">chr", chr, sep = ""), dbSNP, position, ref_allele, var_allele, ref_counts + var_counts, var_counts, sep = " ")
  name_file <- paste(wd_seqem, "chr", chr, "_s", 1:nr_samples, ".out", sep = "")
  out <- lapply(1:nr_samples, function(y) write(text[y], file = name_file[y]))

  #CONTROL FILE
  f <- file(paste(wd_seqem, "imprinting_chr", chr, ".ctrl", sep = ""), "w")
  writeLines(paste("Header_files: ", nr_samples, sep = ""), f)
  writeLines(name_file, f)
  writeLines(c(paste("HWE: ", HWE, sep = ""), paste("Debug: ", Debug, sep = ""), paste("MAX_iterations: ", MAX_iterations, sep = ""), paste("EM_threshold: ", EM_threshold, sep = ""), paste("Initial_error: ", Initial_error, sep = ""), paste("Fix_error: ", Fix_error, sep = ""), paste("Min_read_depth: ", Min_read_depth, sep = ""), paste("Outfile: result_chr", chr, ".txt", sep = "")), f)
  close(f)

  #RUN SeqEM
  setwd(wd_seqem)
  system2("seqem", args = paste("imprinting_chr", chr, ".ctrl", sep = ""), stdout = paste("resultcmd_chr", chr, ".txt", sep = ""), stderr = paste("errorcmd_chr", chr, ".txt", sep = ""))

  #READ RESULTS FILE
  outputSeqEM <- readLines(paste("result_chr", chr, ".txt", sep = ""), n = -1)

  #SAVE ESTIMATED ALLELE FREQUENCY AND ERROR RATE
  est <- grep(paste(". ", position, "  iter= [[:digit:]]+  error= [[:digit:]].[[:digit:]]+  p= [[:digit:]].[[:digit:]]+", sep = ""), outputSeqEM, value = TRUE)
  est_errorx <- regmatches(est, regexpr("error= [[:digit:]].[[:digit:]]+", est))
  est_errorx <- regmatches(est_errorx, regexpr("[[:digit:]].[[:digit:]]+", est_errorx))
  est_px <- regmatches(est, regexpr("p= [[:digit:]].[[:digit:]]+", est))
  est_px <- regmatches(est_px, regexpr("[[:digit:]].[[:digit:]]+", est_px))

  est_p <- as.numeric(est_px)
  est_SE <- as.numeric(est_errorx)

  genotypes <- gsub(" ", "", regmatches(outputSeqEM, regexpr(" rr | rv | vv ", outputSeqEM)))
  f_inb <- ((2 * est_p * (1 - est_p) * nr_samples) - length(which(genotypes == "rv"))) / (2 * est_p * (1 - est_p) * nr_samples)
  if (is.nan(f_inb)) f_inb <- 0

  if(remove == T) {
    junk <- dir(path=wd_seqem, pattern=paste("chr", chr, sep = ""))
    removed <- file.remove(junk)
  }
  on.exit(setwd(old), add = TRUE)

  results <- list("allelefreq" = est_p, "SE" = est_SE, "inbr" = f_inb)
  return(results)
}
