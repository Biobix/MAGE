#' Calculate median heterozygous shift for cis-eQTLS.
#'
#'\code{median_imprinting} calculates median allele-specific expression of allelic counts for a SNP.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param allelefreq Number. Allele frequency.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @return Median ASE value of \code{ref_counts} and \code{var_counts} taking into account \code{allelefreq} and \code{inbr}.
#' @export
#' @examples
#' median_eqtl(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.12)
#' median_eqtl(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5, 0.12)
#' median_eqtl(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5)

median_eqtl <- function(ref_counts, var_counts, allelefreq, inbr = 0) {
  median_hetero <- round(length(ref_counts) * allelefreq * (1 - allelefreq) * (1 - inbr))
  ratios_hetero <- apply(data.frame(ref_counts, var_counts), 1, min) / apply(data.frame(ref_counts, var_counts), 1, max)
  df_ratios <- data.frame("ref" = ref_counts, "var" = var_counts, "hetero" = ratios_hetero, "ratio" = var_counts / (var_counts + ref_counts))
  df_ratios <- df_ratios[order(-df_ratios$hetero), ]

  med_ase <- (df_ratios[median_hetero, "ratio"] - 0.5) / 0.5
  if (length(med_ase) == 0) med_ase <- 0
  return(med_ase)
}
