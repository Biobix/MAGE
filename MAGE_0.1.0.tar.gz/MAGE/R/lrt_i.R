#' Estimate the degree of imprinting.
#'
#'\code{i_lrt} calculates the degree of imprinting using a likelihood ratio test for a specific SNP.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param allelefreq Number. Allele frequency.
#' @param SE Number. Sequencing error rate.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @export
#' @return A list containing the following components:
#' \item{est_i}{The estimated degree of imprinting.}
#' \item{LRT}{The test statistic of the likelihood ratio test.}
#' \item{p_value}{The p-value of the likelihood ratio test.}
#' \item{GOF_likelihood}{The goodness-of-fit value based on the corrected likelihood.}
#' @examples
#' lrt_i(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.002)
#' lrt_i(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5, 0.002, 0.12)

lrt_i <- function(ref_counts, var_counts, allelefreq, SE, inbr = 0) {
  #PMF1 => i = 0
  PMF1 <- MAGE::pmf_impr(ref_counts, var_counts, allelefreq, 0, SE, inbr)

  #PMF2 => i = î
  i_est <- 0
  product_max <- -Inf
  PMF2 <- rep(0, length(ref_counts))
  for (i in seq(0, 1, 0.01)) {
    PMF2_iest <- MAGE::pmf_impr(ref_counts, var_counts, allelefreq, i, SE, inbr)
    product_est <- sum(log(PMF2_iest))
    if (product_est > product_max) {
      product_max <- product_est
      i_est <- i
      PMF2 <- PMF2_iest
    }
  }

  #LRT: DETECTION OF IMPRINTING
  LRT <- - 2 * sum(log(PMF1)) + 2 * sum(log(PMF2))

  #DETERMINE P WITH CORRECTED NULL DISTRIBUTION
  p_impr <- 1 / 2 * pchisq(LRT, 1, lower.tail = FALSE) + 1 / 2 * pchisq(LRT, 0, lower.tail = FALSE)

  #GOF BASED ON CORRECTED LIKELIHOODS
  PMF_corrected <- MAGE::pmf_impr(ref_counts, var_counts, allelefreq, i_est, SE, inbr) * (ref_counts + var_counts + 1)
  logLikelihood <- mean(log(PMF_corrected))

  results <- list("est_i" = i_est, "LRT" = LRT, "p_value" = p_impr, "GOF_likelihood" = logLikelihood)
  return(results)
}
