#' Probability Mass Function for a SNP with imprinting.
#'
#'\code{pmf_impr} calculates the probability of observing specific coverages for each allele for a specific SNP
#'    with possible imprinting. It takes into account allele frequencies, sequencing error rates and inbreeding.
#'
#' @param ref_counts Number or Numeric list. Reference count(s).
#' @param var_counts Number or Numeric list. Variant count(s).
#' @param allelefreq Number. Allele frequency.
#' @param impr Number. Degree of imprinting.
#' @param SE Number. Sequencing error rate.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @return Probability of observing coverages for \code{ref_counts} and \code{var_counts} with
#'     \code{impr} as the probability of success.
#' @export
#' @examples
#' pmf_impr(10, 10, 0.5, 0, 0.002, 0.12)
#' pmf_impr(10, 10, 0.5, 1, 0.002)
#' pmf_impr(0, 10, 0.5, 1, 0.002, 0.12)
#' pmf_impr(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 1, 0.002, 0.12)
#' pmf_impr(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5, 1, 0.002)

pmf_impr <- function(ref_counts, var_counts, allelefreq, impr, SE, inbr = 0) {
  pr <- allelefreq ^ 2 + (inbr * allelefreq * (1 - allelefreq))
  pv <- (1 - allelefreq) ^ 2 + (inbr * allelefreq * (1 - allelefreq))
  prv <- allelefreq * (1 - allelefreq) * (1 - inbr)

  x_m <- MAGE::multinomial_coeff(ref_counts, var_counts)

  c1 <- ((0.5 - impr / 2) / (1 - impr / 2)) * (1 - SE) + (0.5 / (1 - impr / 2)) * SE
  c2 <- (0.5 / (1 - impr / 2)) * (1 - SE) + ((0.5 - impr / 2) / (1 - impr / 2)) * SE

  #homo
  m_RR <- x_m * (1 - SE) ^ ref_counts * SE ^ var_counts
  m_VV <- x_m * SE ^ ref_counts * (1 - SE) ^ var_counts
  #hetero
  m_RV <- x_m * c1 ^ ref_counts * c2 ^ var_counts
  m_VR <- x_m * c2 ^ ref_counts * c1 ^ var_counts

  PMF <- as.numeric(pr * m_RR + pv * m_VV + prv * m_RV + prv * m_VR)
  return(PMF)
}
