#' Difference in median allelic ratio.
#'
#' \code{median_AI} determines the difference between the median allelic ratio of the putative heterozygous
#'   samples in cases versus controle.
#'
#' @param ref_counts_c,var_counts_c Numeric lists. Reference and variant counts of control samples.
#' @param ref_counts_t,var_counts_t Numeric lists. Reference and variant counts of cases.
#' @param allelefreq Number. Allele frequency.
#' @param nr_samples_c,nr_samples_t Number. The number of control samples and diseased samples, respectively.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @return The absolute difference between median allelic ratios of the putative heterozygous samples of \code{ref_counts} and
#'   \code{var_counts} in cases vs controls taking into account \code{allelefreq} and \code{inbr}.
#' @export
# #' @examples
# #' median_AI(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.12)
# #' median_AI(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5)

median_AI <- function(ref_counts_c, var_counts_c, ref_counts_t, var_counts_t, allelefreq, nr_samples_c, nr_samples_t, inbr = 0) {
  hetero_frac <- 2 * allelefreq * (1 - allelefreq) * (1 - inbr)

  ratios_c <- sort(apply(data.frame(ref_counts_c, var_counts_c), 1, min) / apply(data.frame(ref_counts_c, var_counts_c), 1, max), decreasing = TRUE)
  ratios_t <- sort(apply(data.frame(ref_counts_t, var_counts_t), 1, min) / apply(data.frame(ref_counts_t, var_counts_t), 1, max), decreasing = TRUE)
  hetero_c <- ratios_c[1:round(hetero_frac * length(ratios_c))]
  hetero_t <- ratios_t[1:round(hetero_frac * length(ratios_t))]

  if ((nr_samples_c - length(ratios_c)) > 0) {
    hetero_zero_c <- rep(0, nr_samples_c - length(ratios_c))[1:round(hetero_frac * (nr_samples_c - length(ratios_c)))]
    hetero_c <- c(hetero_c, hetero_zero_c)
  }
  if((nr_samples_t - length(ratios_t)) > 0) {
    hetero_zero_t <- rep(0, nr_samples_t - length(ratios_t))[1:round(hetero_frac * (nr_samples_t - length(ratios_t)))]
    hetero_t <- c(hetero_t, hetero_zero_t)
  }

  median_c_hetero <- median(hetero_c)
  median_t_hetero <- median(hetero_t)
 return(abs(median_t_hetero - median_c_hetero))
}
