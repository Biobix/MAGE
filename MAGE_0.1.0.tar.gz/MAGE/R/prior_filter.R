#' Prior filtering of SNP positions.
#'
#' \code{prior_filter} filters SNP positions prior to imprinting analysis: Bayes filter, filtering on estimated allele frequency, removal of non-standard allelic counts and filtering on median coverage and number of samples.
#'
#' @param data_pos Data frame of a SNP position with columns: "chromosome", "position", "ref_alleles", "dbSNP_ref", "gene", "A", "T", "C", "G", "sample", "sample_nr".
#' @param prior_allelefreq Number. Prior allele frequency to filter SNPs on (default is 0.1).
#' @param coverage_filter Number. Minimal median coverage necessary to retain SNP position (default is 5).
#' @param samples_filter Number. Minimal number of samples necessary to retain SNP position (default is 30).
#' @export
#' @return The data as data frame with total and median coverage or NULL if the SNP positions was filtered.

prior_filter <- function(data_pos, prior_allelefreq = 0.1, coverage_filter = 5, samples_filter = 30) {
  ref_alleles <- unlist(strsplit(data_pos$ref_alleles[1], "/"))

  allelecount_samples <- lapply(1:nrow(data_pos), function(y) c(data_pos$A[y], data_pos$T[y], data_pos$C[y], data_pos$G[y]))
  allelecount_samples_percent <- lapply(1:nrow(data_pos), function(y) allelecount_samples[[y]] / sum(allelecount_samples[[y]]) * 100)
  allelecount_samples_table <- lapply(1:nrow(data_pos), function(y) setNames(allelecount_samples_percent[[y]], c("A", "T", "C", "G")))

  allelecount_loci <- colSums(matrix(unlist(allelecount_samples), ncol = 4, byrow = T))
  allelecount_loci_percent <- allelecount_loci / sum(allelecount_loci) * 100
  allelecount_loci_table <- setNames(allelecount_loci_percent, c("A", "T", "C", "G"))

  #FILTERING
  alleles_loci_ordered <- sort(allelecount_loci_table, TRUE)
  whichsample <- hash::hash(data_pos$sample, 1:nrow(data_pos))
  for (s in as.character(data_pos$sample)) {
    alleles_samples_ordered <- sort(allelecount_samples_table[[whichsample[[s]]]], TRUE)
    highest_sample_alleles <- names(alleles_samples_ordered)
    if (highest_sample_alleles[1] %in% ref_alleles && highest_sample_alleles[2] %in% ref_alleles) {
      data_pos <- data_pos
    } else if (!(highest_sample_alleles[1] %in% ref_alleles)) {
      data_pos <- data_pos[-which(data_pos$sample == s), ]
    } else if (!(highest_sample_alleles[2] %in% ref_alleles)) {
      p1 <- (as.numeric(alleles_samples_ordered[1]) + as.numeric(alleles_samples_ordered[2])) / 2
      p3 <- (as.numeric(alleles_samples_ordered[3]) + as.numeric(alleles_samples_ordered[4])) / 2
      p_data_hetero <- dmultinom(as.numeric(alleles_samples_ordered), prob = c(p1, p1, p3, p3))
      p1 <- as.numeric(alleles_samples_ordered[1])
      p2 <- (as.numeric(alleles_samples_ordered[2]) + as.numeric(alleles_samples_ordered[3]) + as.numeric(alleles_samples_ordered[4])) / 3
      p_data_homo <- dmultinom(as.numeric(alleles_samples_ordered), prob = c(p1, p2, p2, p2))
      p_allele <- ref_alleles[which(ref_alleles %in% highest_sample_alleles[1])]
      q_allele <- highest_sample_alleles[2]
      p <- as.numeric(allelecount_loci_table[which(names(allelecount_loci_table) == p_allele)])
      q <- as.numeric(allelecount_loci_table[which(names(allelecount_loci_table) == q_allele)])
      p_homo <- p ^ 2
      p_hetero <- 2 * p * q
      if (p_data_hetero * p_hetero >= p_data_homo * p_homo) {
        data_pos <- data_pos[-which(data_pos$sample == s), ]
      } else {
        data_pos <- data_pos
      }
    }
  }

  if (nrow(data_pos) == 0 || allelecount_loci_percent[which(is.element(c("A", "T", "C", "G"), data_pos$var[1]))] / 100 <= prior_allelefreq) return(NULL)

  #DELETE NON_STANDARD ALLELES FROM SEQUENCES
  if (any(data_pos$ref_count + data_pos$var_count == 0)) data_pos <- data_pos[- which(data_pos$ref_count + data_pos$var_count == 0), ]
  if (nrow(data_pos) == 0) return(NULL)

  #FILTER ON COVERAGE AND ON NUMBER OF SAMPLES
  data_pos$total <- data_pos$ref_count + data_pos$var_count
  data_pos$coverage <- median(data_pos$total)
  if (data_pos$coverage < coverage_filter || nrow(data_pos) < samples_filter) return(NULL)

  return(data_pos)
}
