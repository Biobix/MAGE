#' Estimate the allelic shift for cis-eQTLs.
#'
#' \code{lrt_eqtl} calculates the degree of heterozygous shift for cis-eQTLS using a likelihood ratio test for a specific SNP.
#'
#' @param data_counts Data frame. Data frame of a SNP with reference and variant counts ("ref_count" and
#'     "var_count", respectively) for each sample ("sample").
#' @param norm_counts Data frame. Data frame with library sizes ("counts") for each sample ("sample").
#' @param allelefreq Number. Allele frequency.
#' @param SE Number. Sequencing error rate.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @param dltaco Number. Minimal diffenence between 2 iterations (default = 0.001).
#' @param HWE Logical. Should HWE be used for allele frequency estimation (default = TRUE).
#' @export
#' @return A list containing the following components:
#' \item{AE}{The estimated allelic shift.}
#' \item{AE_lrt}{The test statistic of the likelihood ratio test.}
#' \item{AE_p}{The p-value for the likelihood ratio test.}
#' \item{GOF}{The goodness-of-fit value based on the corrected likelihood.}
#' \item{nrep}{The number of iterations.}
#' \item{rawcor_p}{The p-value of the correlation test.}
#' \item{rawcor_R}{The R-value of the correlation test.}
#' \item{quality}{Indicates the quality of a SNP positions. An "!" idicates bad quality SNPs for which the correct shift
#'     cannot be calculated.}
# #' @examples
# #' lrt_eqtl(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.0015, 0.12, 0.0005)
# #' lrt_eqtl(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5, 0.0015)

lrt_eqtl <- function(data_counts, norm_counts, allelefreq, SE, inbr = 0, dltaco = 0.001, HWE = TRUE) {
  #scaling factors
  mean_norms <- mean(norm_counts[, "counts"])
  norm_counts <- norm_counts[match(data_counts$sample, norm_counts$sample), ]
  norm_counts$norms <- norm_counts[, "counts"]/mean_norms
  data_counts[, c("ref_norm", "var_norm")] <- data_counts[, c("ref_count", "var_count")]/norm_counts$norms
  rawcor <- cor.test(data_counts$ref_norm + data_counts$var_norm, data_counts$ref_count/(data_counts$ref_count + data_counts$var_count))

  probshift <- 0.5
  dlta <- 1
  nrep <- 0
  prv <- 2 * allelefreq * (1 - allelefreq) * (1 - inbr)
  pr <- allelefreq^2 + inbr * allelefreq * (1 - allelefreq)
  pv <- (1 - allelefreq)^2 + inbr * allelefreq * (1 - allelefreq)

  while (dlta > dltaco & nrep < 100) {
    nrep <- nrep + 1
    probshiftold <- probshift
    spv <- pv * dbinom(data_counts$var_count, data_counts$ref_count + data_counts$var_count, prob = 1 - SE)
    sprv <- prv * dbinom(data_counts$ref_count, data_counts$ref_count + data_counts$var_count, prob = probshift)
    spr <- pr * dbinom(data_counts$ref_count, data_counts$ref_count + data_counts$var_count, prob = 1 - SE)
    pdata <- rowSums(cbind(spv, sprv, spr))

    if (any(pdata == 0) | identical(sprv, pdata) | all(round(sprv/pdata) == 1)) {
      data_counts$pvv <- spv; data_counts$prr <- spr; data_counts$prv <- sprv

      dmixase <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr)
      dmixh0 <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, 0.5, allelefreq, SE, inbr)
      lrtstat <- -2 * (sum(log(dmixh0)) - sum(log(dmixase)))
      pval <- pchisq(lrtstat, df = 1, lower.tail = F)
      dmixase_corrected <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr) * (data_counts$ref_count + data_counts$var_count + 1)
      logLikelihood <- mean(log(dmixase_corrected))
      probshift_adj <- -(as.numeric(probshift) - 0.5)/0.5

      results <- list(AE = probshift_adj, AE_lrt = lrtstat, AE_p = pval, GOF = logLikelihood, nrep = nrep - 1, rawcor_p = rawcor$p.value, rawcor_R = rawcor$estimate, quality = "!", pvv = pv ,prr = pr, prv = prv, data_hash = data_counts)
      return(results)
    }

    spv <- spv/pdata
    sprv <- sprv/pdata
    spr <- spr/pdata
    if (HWE) {
      allelefreq <- mean(spr) + mean(sprv)/2
      prv <- 2 * allelefreq * (1 - allelefreq) * (1 - inbr)
      pr <- allelefreq^2 + inbr * allelefreq * (1 - allelefreq)
      pv <- (1 - allelefreq)^2 + inbr * allelefreq * (allelefreq)
    }
    else {
      pv <- sum(spv)
      prv <- sum(sprv)
      pr <- sum(spr)
    }
    aaf <- (spv * 2 + sprv)/2
    probshiftlm <- coef(MASS::rlm(data_counts$ref_norm + data_counts$var_norm ~ aaf))
    probshift <- probshiftlm[1]/(2 * probshiftlm[1] + probshiftlm[2])
    probshift[probshift > 1] <- 1
    probshift[probshift < 0] <- 0
    dlta <- abs(probshiftold - probshift)
  }
  data_counts$pvv <- spv; data_counts$prr <- spr; data_counts$prv <- sprv

  dmixase <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr)
  dmixh0 <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, 0.5, allelefreq, SE, inbr)
  lrtstat <- -2 * (sum(log(dmixh0)) - sum(log(dmixase)))
  pval <- pchisq(lrtstat, df = 1, lower.tail = F)
  dmixase_corrected <- MAGE::pmf_eqtl(data_counts$ref_count, data_counts$var_count, probshift, allelefreq, SE, inbr) * (data_counts$ref_count + data_counts$var_count + 1)
  logLikelihood <- mean(log(dmixase_corrected))
  probshift_adj <- -(as.numeric(probshift) - 0.5)/0.5

  results <- list(AE = probshift_adj, AE_lrt = lrtstat, AE_p = pval, GOF = logLikelihood, nrep = nrep, rawcor_p = rawcor$p.value, rawcor_R = rawcor$estimate, quality = "", pvv = pv ,prr = pr, prv = prv, data_hash = data_counts)
  return(results)
}




