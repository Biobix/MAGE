#' Logistic regression between cases and controls.
#'
#' \code{binomial_logistic} calculates the p-value of the logistic regression in cases compared to control samples.
#'     The logistic regression identifies if there is a higher or lower fraction of heterozygous samples in cases versus controls.
#'
#' @param ref_counts_c,var_counts_c Numeric lists. Reference and variant counts of control samples.
#' @param ref_counts_t,var_counts_t Numeric lists. Reference and variant counts of cases.
#' @export
#' @return Beta-value (beta) and p-value (p.value) of the generalised linear model comparing the fraction of heterozygous samples
#'     in cases versus controls.
# #' @examples
# #' binomial_logistic(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.002, 0.12)
# #' binomial_logistic(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.5, 0.002)

binomial_logistic <- function(ref_counts_c, var_counts_c, ref_counts_t, var_counts_t) {
  counts_c <- data.frame("ref" = ref_counts_c, "var" = var_counts_c)
  counts_c$least <- apply(counts_c[, 1:2], 1, min)
  counts_c$most <- apply(counts_c[, 1:2], 1, max)
  counts_t <- data.frame("ref" = ref_counts_t, "var" = var_counts_t)
  counts_t$least <- apply(counts_t[, 1:2], 1, min)
  counts_t$most <- apply(counts_t[, 1:2], 1, max)

  tumc <- counts_t[, c("least", "most")]
  conc <- counts_c[, c("least", "most")]
  resp <- as.matrix(rbind(tumc, conc))
  status <- as.factor(c(rep("T", nrow(tumc)), rep("C", nrow(conc))))
  tempres <- stats::glm(resp ~ status, family = binomial)
  results <- list("beta" = coef(summary(tempres))[2, 1], "p.value" = coef(summary(tempres))[2, 4])

  return(results)
}

