#' Plot eQTL loci.
#'
#' \code{plot_eqtl} plots the observed and expected allelic counts of eQTLs.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param probshift Number. The binomial probability of success indicating the shift of the heterozygous fraction.
#' @param allelefreq Number. Allele frequency.
#' @param SE Number. Sequencing error rate.
#' @param wd_res String. Working directory where plots are saved.
#' @param position Number. Analysed SNP position.
#' @param chr Number. Analysed chromosome.
#' @param gene String. Analysed gene.
#' @param inbr Number. Degree of inbreeding (default = 0).
#' @param coverage Number. Coverage used for plotting (default = 25).
#' @param plot_H0 Logical. Should PMF under HWE be plotted as well? (default = FALSE).
#' @export
#' @examples
#' plot_eqtl(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0), 0.5, 0.5, 0.002,
#' paste(getwd(), "/", sep=""), 1, 2000, "IGF2", 0.12, 100, TRUE)
#' plot_eqtl(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0), 0.2, 0.5, 0.002,
#' paste(getwd(), "/", sep=""), 1, 2000, "IGF2")

plot_eqtl <- function(ref_counts, var_counts, probshift, allelefreq, SE, wd_res, chr, position, gene, inbr = 0, coverage = 25, plot_H0 = FALSE) {
  x_as <- unlist(seq(0, 1, 0.01))
  fracA <- round(ref_counts / (ref_counts + var_counts), 2)
  y_as <- unlist(lapply(seq(0, 100, 1), function(y) sum(fracA == y / 100) / length(ref_counts)))

  prob_plot <- (1 - probshift) / 2

  fitH1 <- MAGE::pmf_eqtl(seq(0, coverage, 1), (coverage - seq(0, coverage, 1)), prob_plot, allelefreq, SE, inbr)
  fitH0 <- MAGE::pmf_eqtl(seq(0, coverage, 1), (coverage - seq(0, coverage, 1)), 0.5, allelefreq, SE, inbr)

  x_as_cov <- seq(0, 1, 1 / coverage)
  data1 <- data.frame(x_as, y_as)
  data2 <- data.frame(x_as_cov, fitH1)
  data3 <- data.frame(x_as_cov, fitH0)

  pl <- ggplot2::ggplot(data1, ggplot2::aes(x = x_as, y = y_as)) +
    ggplot2::geom_bar(stat = "identity", width = .0000005, colour = "#D55E00") +
    ggplot2::geom_line(data = data2, ggplot2::aes(x = x_as_cov, y = fitH1), colour = "#0072B2", size = 0.73) +
    ggplot2::xlab("Fraction") +
    ggplot2::ylab("Frequency") +
    ggplot2::theme(plot.title = ggplot2::element_text(lineheight = .8), axis.text = ggplot2::element_text(size = 28), axis.title = ggplot2::element_text(size=32)) +
    ggplot2::theme_classic() +
    ggplot2::theme(axis.text = ggplot2::element_text(size = 28), axis.title = ggplot2::element_text(size = 32))

  if(plot_H0) pl <- pl + ggplot2::geom_line(data = data3, ggplot2::aes(x = x_as_cov, y = fitH0), colour = "#7CAB3B", size = 0.6)

  ggplot2::ggsave(filename = paste(wd_res, "eQTL_chr", chr, "_", position, "_", gene, ".png", sep = ""), plot = pl, width = 10, height = 8, units = "in", dpi = 300)
}
