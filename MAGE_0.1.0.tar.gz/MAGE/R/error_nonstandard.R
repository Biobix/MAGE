#' Sequencing error rate of non-standard alleles.
#'
#' \code{error_nonstandard} calculates the sequencing error rate taken into account non-standard alleles.
#'
#' @param data_hash Hash. Hash of SNP positions with a data frame for every SNP position with counts per allele and reference and variant counts.
#' @return Robust estimate of the sequencing error rate.
#' @export

error_nonstandard <- function(data_hash) {
  errors <- 0
  all_counts <- 0
  for (z in hash::keys(data_hash)) {
    all_counts <- all_counts + sum(data_hash[[z]][, c("A", "T", "C", "G")])
    errors <- errors + sum(data_hash[[z]][, c("A", "T", "C", "G")]) - sum(data_hash[[z]][, c("ref_count", "var_count")])

  }
  return(errors / all_counts / 2)
}

