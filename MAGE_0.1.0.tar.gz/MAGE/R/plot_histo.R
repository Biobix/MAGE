#' Plot allelic counts as a histogram.
#'
#' \code{plot_histo} plots the observed allelic counts of a locus.
#'
#' @param ref_counts Numeric list. Reference counts.
#' @param var_counts Numeric list. Variant counts.
#' @param wd_res String. Working directory where plots are saved.
#' @param position Number. Analysed SNP position.
#' @param chr Number. Analysed chromosome.
#' @param gene String. Analysed gene.
#' @export
#' @examples
#' plot_histo(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0),
#'    paste(getwd(), "/", sep=""), 1, 2000, "IGF2")
#' plot_histo(c(5, 0, 0, 3, 5, 1, 23), c(1, 8, 6, 2, 0, 10, 0),
#'    paste(getwd(), "/", sep=""), 1, 2000, "IGF2")

plot_histo <- function (ref_counts, var_counts, wd_res, chr, position, gene) {
  x_as <- unlist(seq(0, 1, 0.01))
  nr_samples <- length(ref_counts)

  fracA <- round(ref_counts / (ref_counts + var_counts), 2)
  y_as <- unlist(lapply(seq(0, 100, 1), function(y) sum(fracA == y / 100) / nr_samples))

  data1 <- data.frame(x_as, y_as)

  pl <- ggplot2::ggplot(data1, ggplot2::aes(x = x_as, y = y_as)) +
    ggplot2::geom_bar(stat = "identity", width = .0000005, colour = "#D55E00") +
    ggplot2::xlab("Fraction") +
    ggplot2::ylab("Frequency") +
    ggplot2::theme(plot.title = ggplot2::element_text(lineheight = .8), axis.text = ggplot2::element_text(size=28), axis.title = ggplot2::element_text(size=32)) +
    ggplot2::theme_classic() +
    ggplot2::theme(axis.text = ggplot2::element_text(size=28), axis.title = ggplot2::element_text(size=32))

  ggplot2::ggsave(filename = paste(wd_res, "chr", chr, "_", position, "_", gene, ".png", sep = ""), plot = pl, width = 10, height = 8, units = "in", dpi = 300, device = "png")
}
