#' Determine multinomial coefficient.
#'
#'\code{multinomial_coeff} calculates the multinomial coefficient for a specific SNP.
#'
#' @param ref_counts Number or Numeric list. Reference count(s).
#' @param var_counts Number or Numeric list. Variant count(s).
#' @return The multinomial coefficient of \code{ref_counts} and \code{var_counts}.
#' @export
#' @examples
#' multinomial_coeff(5, 11)
#' multinomial_coeff(c(5, 8, 10, 3, 5, 6, 23), c(8, 8, 6, 4, 4, 10, 0))

multinomial_coeff <- function(ref_counts, var_counts) {
  x_m <- gmp::factorialZ(ref_counts + var_counts) / (gmp::factorialZ(ref_counts) * gmp::factorialZ(var_counts))
  return(x_m)
}
