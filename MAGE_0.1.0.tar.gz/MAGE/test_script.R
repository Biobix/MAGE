library("devtools")
library(roxygen2)
devtools::load_all()

document()
#check()

setwd("..")
build("MAGE")
install("MAGE")

chromosomes <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22)
wd_samples <- "C:/Users/Tine/OneDrive - UGent/UGent/Rpackage/test/kidney/"
wd_seq <-  "C:/Users/Tine/OneDrive - UGent/UGent/Rpackage/test/kidney/"
wd_seqem <- "C:/Users/Tine/Documents/UGent/imprinting/SeqEM_data/"; if(!dir.exists(wd_seqem)) dir.create(wd_seqem)
wd_res <- "C:/Users/Tine/OneDrive - UGent/UGent/Rpackage/test/kidney/imprinted/"; if(!dir.exists(wd_res)) dir.create(wd_res)

file_samples <- paste(wd_samples, "samples.txt", sep = "")
file_samples_t <- paste(wd_samples, "samples_tumor.txt", sep = "")
file_sequences <- paste(wd_seq, "counts_SNP_chr", sep = "")
# file_sequences_t <- paste(wd_seq_tumor, "counts_SNP_chr", sep = "")
# file_sequences_t <- paste(wd_seq, "counts_SNP_tumor_chr", sep = "")

pA_estimate_filt <- 0.1
pA_filt <- 0.15
cov_filt <- 4
nr_samples_filt <- 30
SE_filt <- 0.035
sym_filt <- 0.05
GOF_filt <- 0.8
impr_filt <- 0.6
median_filt <- 0.8
p_filt <- 0.05
plot_coverage <- 40
plot_HWE <- FALSE

#######
#START#
#######

sample_info <- read.table(file_samples, header = FALSE, stringsAsFactors = FALSE, sep = "\t")
names(sample_info) <- c("sample_nr", "sample")
samples_all <- sample_info$sample
nr_samples_all <- length(samples_all)

sample_info_t <- read.table(file_samples_t, header = FALSE, stringsAsFactors = FALSE, sep = "\t")
names(sample_info_t) <- c("sample_nr", "sample")
samples_t <- sample_info_t$sample
nr_samples_t <- length(samples_t)

chr <- 15
for (chr in chromosomes) {
  #READ COUNT FILES
  sample_data <- read.table(paste(file_sequences, chr, ".txt", sep=""), header = FALSE, stringsAsFactors = F, sep = "\t")
  names(sample_data) <- c("chromosome", "position", "ref_alleles", "variationtype", "dbSNP_ref", "gene", "A", "T", "C", "G", "sample")
  sample_data$sample_nr <- unlist(lapply(sample_data$sample, function(x) sample_info[which(sample_info$sample == x), "sample_nr"]))
  sample_data$position <- as.character(sample_data$position)

  #DETERMINE AMOUNT OF LOCI
  positions <- unique(sample_data$position)
  loci <- length(positions)

  #CREATE HASH WITH DATA FRAME FOR EVERY POSITION
  data <- hash::hash()
  for (i in positions) {
    data[[ i ]] <- sample_data[which(sample_data$position==i), ]
  }

  #DELETE INDELS AND SUBSTITUTIONS
  for (z in positions) {
    if (data[[z]]$variationtype[1] != "SNV" || grepl('\\.', strsplit(data[[z]]$ref_alleles[1], "/"))) {
      data[[z]] <- NULL
    }
  }
  positions <- hash::keys(data); loci <- length(positions)

  #DETERMINE STANDARD ALLELES AND REFERENCE/VARIANT COUNTS
  data_c <- hash::hash()
  for (z in positions) {
    data[[z]] <- MAGE::standard_alleles(data[[z]])
    #SAVE CONTROL DATA BEFORE FILTERING
    data_c[[z]] <- data[[z]]
  }

  #PRIOR FILTER OF LOCI
  for (z in positions) {
    data[[z]] <- MAGE::prior_filter(data[[z]], prior_allelefreq = pA_estimate_filt, coverage_filter = cov_filt, samples_filter = nr_samples_filt)
  }
  positions <- hash::keys(data); loci <- length(positions)

  #ESIMATE PARAMETERS WITH SeqEM (SEQUENCING ERROR RATE, ALLELE FREQUENCY AND INBREEDING), CALCUTE SYMMETRY GOF PER SNP AND FILTER SNPS
  SE_all <- NULL; F_all <- NULL
  for (z in positions) {
    seqem_results <- MAGE::estimate_parameters(data[[z]]$ref_count, data[[z]]$var_count, wd_seqem, ref_allele = data[[z]][1, "ref"], var_allele = data[[z]][1, "var"], position = z, dbSNP = data[[z]][1, "dbSNP_ref"], chr = chr)
    data[[z]]$allelefreq <- seqem_results$allelefreq
    data[[z]]$est_SE <- seqem_results$SE
    data[[z]]$est_inbr <- seqem_results$inbr
    SE_all <- c(SE_all, seqem_results$SE)
    F_all <- c(F_all, seqem_results$inbr)

    data[[z]]$sym <- MAGE::symmetry_gof(data[[z]]$ref_count, data[[z]]$var_count, seqem_results$allelefreq)

    if (seqem_results$allelefreq <= pA_filt || seqem_results$allelefreq >= (1 - pA_filt) || seqem_results$SE > SE_filt ||data[[z]]$sym[1] <= sym_filt) {
      data[[z]] <- NULL
    }
  }
  f_inb_chr <- median(F_all)
  SE <- median(SE_all)
  positions <- hash::keys(data); loci <- length(positions)

  #PERFORM IMPRINTING ANALYSIS PER SNP AND CREATE RESULTS DATA FRAME
  results <- data.frame()
  for (z in positions) {
    lrt_results <- MAGE::lrt_i(data[[z]]$ref_count, data[[z]]$var_count, allelefreq = data[[z]][1, "allelefreq"], SE = SE, inbr = f_inb_chr)
    med_imp <- MAGE::median_imprinting(data[[z]]$ref_count, data[[z]]$var_count, allelefreq = data[[z]][1, "allelefreq"], inbr = f_inb_chr)
    results_z <- data.frame("position" = z, "gene" = data[[z]]$gene[1], "LRT" = lrt_results$LRT, "p" = lrt_results$p_value, "estimated.i" = lrt_results$est_i, "allele.frequency" = data[[z]]$allelefreq[1], "dbSNP" = data[[z]]$dbSNP_ref[1], "reference" = data[[z]]$ref[1], "variant" = data[[z]]$var[1], "est_SE" = data[[z]]$est_SE[1], "coverage" = data[[z]]$coverage[1], "nr_samples" = nrow(data[[z]]), "GOF" = lrt_results$GOF_likelihood, "symmetry" = data[[z]]$sym[1], "med_impr" = med_imp, "est_inbreeding" = est_inbr, "tot_inbreeding" = f_inb_chr, stringsAsFactors = FALSE)
    results <- rbind(results, results_z)
  }

  #FINAL FILTERING OF INTERESTING AND IMPRINTED SNPS AND WRITE RESULTS FILES
  results <- MAGE::final_filter(chr, data, results, wd_res, gof_filt = GOF_filt, adj_p_filt = 0.05, med_impr_filt = median_filt, i_filt = impr_filt, file_all = TRUE, file_impr = TRUE, file_all_counts = FALSE, file_impr_counts = TRUE)

  positions_impr <- as.character(results$position)

  #PLOT SIGNIFICANTLY IMPRINTED GENES#
  if (length(positions_impr) > 0) {
    for (z in positions_impr) {
      MAGE::plot_imprinting(data[[z]]$ref_count, data[[z]]$var_count, allelefreq = results[which(results$position==z), "allele.frequency"], impr = results[which(results$position==z), "estimated.i"], SE = SE, wd_res = wd_res, chr = chr, position = z, gene  = results[which(results$position==z), "gene"], inbr = f_inb_chr, coverage = plot_coverage, plot_hwe = plot_HWE)
    }
  }

  ####################
  #ANALYSE TUMOR DATA#
  ####################
  if (length(positions_impr) > 0) {
    #READ COUNT FILES
    sample_data_t <- read.table(paste(file_sequences_t, chr, "_tumor.txt", sep=""), header = FALSE, stringsAsFactors = F, sep = "\t")
    #sample_data_t <- read.table(paste(file_sequences_t, chr, ".txt", sep=""), header = FALSE, stringsAsFactors = F, sep = "\t")
    names(sample_data_t) <- c("chromosome", "position", "ref_alleles", "dbSNP_ref", "gene", "A", "T", "C", "G", "sample")
    sample_data_t$sample_nr <- unlist(lapply(sample_data_t$sample, function(x) sample_info_t[which(sample_info_t$sample == x), "sample_nr"]))
    sample_data_t$position <- as.character(sample_data_t$position)

    positions_all <- hash::keys(data_c)[which(hash::keys(data_c) %in% unique(sample_data_t$position))]
    data_t <- hash::hash()
    data_all <- hash::hash()
    for (z in positions_all) {
      data_t[[z]] <- sample_data_t[which(sample_data_t$position == z), ]
      data_t[[z]]$ref_alleles <- data_c[[z]]$ref_alleles[1]
      data_t[[z]] <- MAGE::standard_alleles(data_t[[z]])
      data_all[[z]] <- rbind(data_c[[z]], data_t[[z]])
    }

    positions_impr <- positions_impr[which(positions_impr %in% unique(sample_data_t$position))]

    ##DIFFERENTIAL IMPRINTING/LOI
    p_LOI <- hash::hash()
    for (z in positions_impr) {
      p_LOI[[z]] <- MAGE::binomial_logistic(data[[z]]$ref_count, data[[z]]$var_count, data_t[[z]]$ref_count, data_t[[z]]$var_count)$p.value
    }

    #DETERMINE SE BASED ON NON_STANDARD ALLELES
    SE_nonstandard <- MAGE::error_nonstandard(data_all)

    impr_genes <- unique(unlist(strsplit(results$gene, ",")))

    p_total <- hash::hash()
    LOI_samples <- hash::hash()
    for (gene in impr_genes) {
      pos_gene <- as.character(results[grep(gene, results$gene), "position"])

      ##COMBINE P-VALUES LOI PER GENE
      test_statistic <- - 2 * sum(log(hash::values(p_LOI[pos_gene])))
      p_total[[gene]] <- pchisq(test_statistic, 2 * length(hash::values(p_LOI[pos_gene])), lower.tail = FALSE)

      ##CALL LOI SAMPLES PER GENE IN CONTROL AND TUMOR DATA
      LOI_samples[[gene]] <- MAGE::LOI_calling(data_all[pos_gene], c(samples_all, samples_t), SE_nonstandard)
    }
  }
}


